
class Timer(object):

    def __init__(self):
        pass

    def update(seld, seconds):
        pass