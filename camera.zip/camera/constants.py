from vector import vec, pyVec
import pygame 

RESOLUTION = vec(400,200)
WORLD_SIZE = vec(800,400)

SCALE = 2
UPSCALED = RESOLUTION * SCALE